import assert from 'node:assert/strict';
import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';
import { execFileSync } from 'node:child_process';
import { SPRITES } from '../public/sprites.js';

const root = fileURLToPath(new URL('../', import.meta.url));
const publicDir = join(root, 'public');
const html = readFileSync(join(publicDir, 'index.html'), 'utf8');
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
assert.equal(new Set(ids).size, ids.length, 'HTML IDs must be unique');
const app = readFileSync(join(publicDir, 'app.js'), 'utf8');
for (const match of app.matchAll(/\$\('([^']+)'\)/g)) assert.ok(ids.includes(match[1]), `Missing HTML control: ${match[1]}`);
for (const match of html.matchAll(/(?:src|href)="([^"#]+)"/g)) {
  if (match[1] === './') continue;
  assert.ok(existsSync(resolve(publicDir, match[1])), `Missing asset: ${match[1]}`);
}
for (const path of Object.values(SPRITES).flat()) {
  const bytes = readFileSync(join(publicDir, path));
  assert.equal(bytes.subarray(1, 4).toString(), 'PNG', `Invalid PNG: ${path}`);
}
for (const folder of ['public', 'scripts', 'tests']) {
  for (const file of readdirSync(join(root, folder))) {
    if (/\.(?:mjs|js)$/.test(file)) execFileSync(process.execPath, ['--check', join(root, folder, file)]);
  }
}
const config = JSON.parse(readFileSync(join(root, 'vercel.json'), 'utf8'));
assert.equal(config.outputDirectory, 'public');
assert.ok(existsSync(join(root, config.outputDirectory, 'index.html')));
assert.equal(Object.values(SPRITES).flat().length, 17);
console.log('PASS: JavaScript syntax, HTML controls, 17 PNG sprites, local assets, and Vercel output.');

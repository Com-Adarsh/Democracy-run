import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const publicDir = join(root, 'public');
const dataUrl = name => `data:${name.endsWith('.svg') ? 'image/svg+xml' : 'image/png'};base64,${readFileSync(join(publicDir, name)).toString('base64')}`;
let html = readFileSync(join(publicDir, 'index.html'), 'utf8');
const css = readFileSync(join(publicDir, 'styles.css'), 'utf8');
html = html.replace('<link rel="stylesheet" href="styles.css">', `<style>${css}</style>`);
html = html.replaceAll(/(?:assets\/[a-z0-9-]+\.(?:png|svg))/g, dataUrl);
let js = ['core.js', 'sprites.js', 'storage.js', 'audio.js', 'renderer.js', 'app.js'].map(name => {
  let source = readFileSync(join(publicDir, name), 'utf8');
  source = source.replace(/^import .*;\s*$/gm, '').replace(/^export /gm, '');
  if (name === 'sprites.js') source = source.replace(/assets\/[a-z0-9-]+\.png/g, dataUrl);
  return source;
}).join('\n');
js = js.replaceAll('</script', '<\\/script');
html = html.replace('<script type="module" src="app.js"></script>', `<script>(() => {\n${js}\n})();</script>`);
writeFileSync(join(root, 'PLAY.html'), html);
console.log('Created PLAY.html: self-contained game, styles, and 17 animation frames.');

// Gameplay extracted from The Democracy Run v1.3 and separated from its UI.
// Units: logical pixels and seconds. The original physics and scoring are retained.
export const RULES = Object.freeze({
  width: 960, height: 540, ground: 425, gravity: 1780,
  jumpVelocity: -760, slideSeconds: 0.58, jumpBufferSeconds: 0.12,
  initialSpeed: 330, maximumSpeed: 650, pointsPerSecond: 24, flagPoints: 10,
  fixedStep: 1 / 120,
});

export const formatScore = value => String(Math.floor(value)).padStart(5, '0');
export const intersects = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

export function playerBounds(player) {
  // Standing hitbox follows v1.3; crouching now stays anchored to the road.
  return { x: player.x + 11, y: player.slide > 0 ? RULES.ground - 29 : player.y + 12,
    w: player.slide > 0 ? 40 : 32, h: player.slide > 0 ? 29 : 56 };
}

export function obstacleBounds(obstacle) {
  if (obstacle.type === 'banner') return { x: obstacle.x + 4, y: RULES.ground - 115, w: obstacle.w - 8, h: 75 };
  const height = obstacle.type === 'cone' ? 45 : obstacle.type === 'police' ? 73 : 58;
  return { x: obstacle.x + 4, y: RULES.ground - height + 5, w: obstacle.w - 8, h: height - 5 };
}

export function createGame({ random = Math.random, onEvent = () => {} } = {}) {
  let state;
  function reset() {
    state = { mode: 'home', score: 0, flags: 0, speed: RULES.initialSpeed,
      frame: 0, worldDistance: 0, elapsed: 0, spawn: 0.72, flagSpawn: 1.1,
      obstacles: [], collectibles: [], particles: [],
      player: { x: 205, y: RULES.ground - 78, w: 54, h: 78, vy: 0,
        onGround: true, slide: 0, jumpBuffer: 0 } };
  }
  function start() { reset(); state.mode = 'running'; onEvent('start', state); }
  function jump() {
    if (state.mode !== 'running') return;
    const p = state.player;
    p.jumpBuffer = RULES.jumpBufferSeconds;
    if (p.onGround && p.slide <= 0) launchJump();
  }
  function launchJump() {
    Object.assign(state.player, { vy: RULES.jumpVelocity, onGround: false, jumpBuffer: 0 });
    onEvent('jump', state);
  }
  function slide() {
    if (state.mode === 'running' && state.player.onGround) {
      state.player.slide = RULES.slideSeconds;
      state.player.jumpBuffer = 0;
      onEvent('slide', state);
    }
  }
  function pause() {
    if (state.mode !== 'running') return;
    state.mode = 'paused'; state.player.jumpBuffer = 0; onEvent('pause', state);
  }
  function resume() {
    if (state.mode !== 'paused') return;
    state.mode = 'running'; onEvent('resume', state);
  }
  function home() { reset(); onEvent('home', state); }
  function end() {
    state.mode = 'over'; state.player.jumpBuffer = 0; onEvent('over', state);
  }
  function burst(x, y) {
    for (let i = 0; i < 10; i++) state.particles.push({ x, y,
      vx: (random() - 0.5) * 220, vy: -random() * 200 - 55, life: 0.45, c: i % 2 ? '#ffdc80' : '#ff3945' });
  }
  function step(dt) {
    if (state.mode !== 'running' || !Number.isFinite(dt) || dt <= 0) return;
    // Fixed steps in the controller prevent tunnelling and refresh-rate-dependent jumps.
    dt = Math.min(dt, 1 / 60);
    const s = state, p = s.player;
    s.elapsed += dt; s.frame += dt * 60; s.score += dt * RULES.pointsPerSecond;
    s.speed = Math.min(RULES.maximumSpeed, RULES.initialSpeed + s.score * 0.035);
    s.worldDistance += s.speed * dt;
    s.spawn -= dt;
    if (s.spawn <= 0) {
      const r = random(), type = s.score > 240 && r > 0.94 ? 'banner' : r < 0.24 ? 'cone' : r > 0.86 ? 'police' : 'barrier';
      // Fix the original 24–30% branch: a barricade must have barricade width.
      s.obstacles.push({ x: 1000, w: type === 'banner' ? 100 : type === 'cone' ? 34 : 76, type });
      s.spawn += Math.max(0.78, 1.55 - (s.speed - 330) * 0.001 + random() * 0.38);
    }
    s.flagSpawn -= dt;
    if (s.flagSpawn <= 0) {
      s.collectibles.push({ x: 1000 }); s.flagSpawn += 1.65 + random() * 1.55;
    }
    p.jumpBuffer = Math.max(0, p.jumpBuffer - dt);
    p.slide = Math.max(0, p.slide - dt);
    if (!p.onGround) {
      p.vy += RULES.gravity * dt; p.y += p.vy * dt;
      if (p.y >= RULES.ground - p.h) {
        p.y = RULES.ground - p.h; p.vy = 0; p.onGround = true;
      }
    }
    if (p.onGround && p.slide <= 0 && p.jumpBuffer > 0) launchJump();
    for (const o of s.obstacles) o.x -= s.speed * dt;
    for (const c of s.collectibles) c.x -= s.speed * dt;
    s.obstacles = s.obstacles.filter(o => o.x > -140);
    s.collectibles = s.collectibles.filter(c => c.x > -40);
    const box = playerBounds(p);
    for (const obstacle of s.obstacles) {
      if (intersects(box, obstacleBounds(obstacle))) { end(); return; }
    }
    for (let i = s.collectibles.length - 1; i >= 0; i--) {
      const c = s.collectibles[i];
      if (Math.abs(box.x + box.w / 2 - (c.x + 15)) < 34 &&
          Math.abs(box.y + box.h / 2 - (RULES.ground - 92)) < 60) {
        s.collectibles.splice(i, 1); s.flags++; s.score += RULES.flagPoints;
        burst(c.x, RULES.ground - 100); onEvent('flag', s);
      }
    }
    for (const p of s.particles) { p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 720 * dt; p.life -= dt; }
    s.particles = s.particles.filter(p => p.life > 0);
  }
  reset();
  return { get state() { return state; }, start, jump, slide, pause, resume, home, step };
}

export function createClock(game) {
  let previous = null, accumulator = 0;
  return {
    reset() { previous = null; accumulator = 0; },
    tick(timestamp) {
      if (previous === null) { previous = timestamp; return; }
      const dt = Math.max(0, Math.min((timestamp - previous) / 1000, 0.1));
      previous = timestamp;
      if (game.state.mode !== 'running') { accumulator = 0; return; }
      accumulator += dt;
      while (accumulator + 1e-10 >= RULES.fixedStep) {
        game.step(RULES.fixedStep); accumulator -= RULES.fixedStep;
        if (game.state.mode !== 'running') { accumulator = 0; break; }
      }
    }
  };
}

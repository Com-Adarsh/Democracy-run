export const SPRITES = {
  "run": [
    "assets/run-00.png",
    "assets/run-01.png",
    "assets/run-02.png",
    "assets/run-03.png",
    "assets/run-04.png",
    "assets/run-05.png",
    "assets/run-06.png",
    "assets/run-07.png",
    "assets/run-08.png"
  ],
  "jump": [
    "assets/jump-00.png",
    "assets/jump-01.png",
    "assets/jump-02.png",
    "assets/jump-03.png"
  ],
  "slide": [
    "assets/slide-00.png",
    "assets/slide-01.png",
    "assets/slide-02.png",
    "assets/slide-03.png"
  ]
};

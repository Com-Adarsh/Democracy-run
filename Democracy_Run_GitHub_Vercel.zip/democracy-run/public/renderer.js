import { SPRITES } from './sprites.js';
import { RULES } from './core.js';

// Retains the original Delhi skyline, obstacle art, and all 17 runner frames.
export function createRenderer(canvas) {
const ctx = canvas.getContext('2d');
if (!ctx) throw new Error('Your browser could not start the game canvas.');
const ground = RULES.ground;
let player, frame = 0, worldDistance = 0;
const makeSprites = sources => sources.map(src => { const image = new Image(); image.src = src; return image; });
const runSprites = makeSprites(SPRITES.run), jumpSprites = makeSprites(SPRITES.jump), slideSprites = makeSprites(SPRITES.slide);
const allSprites = [...runSprites, ...jumpSprites, ...slideSprites];
const ready = Promise.all(allSprites.map(im => new Promise(resolve => {
  if (im.complete) resolve(); else { im.onload = resolve; im.onerror = resolve; }
})));
function resize() {
  const scale = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = RULES.width * scale; canvas.height = RULES.height * scale;
  ctx.setTransform(scale, 0, 0, scale, 0, 0); ctx.imageSmoothingEnabled = true;
}
resize();
function rect(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h))}
function line(x1,y1,x2,y2,c,w=1){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke()}
function text(t,x,y,size,color='#fff',align='left'){ctx.font=`900 ${size}px monospace`;ctx.textAlign=align;ctx.fillStyle=color;ctx.fillText(t,x,y)}
function drawSky(){
 const g=ctx.createLinearGradient(0,0,0,ground);
 g.addColorStop(0,'#4d8bd3');g.addColorStop(.52,'#f3a37f');g.addColorStop(1,'#ffe0ad');
 ctx.fillStyle=g;ctx.fillRect(0,0,960,ground);
 const glow=ctx.createRadialGradient(650,185,12,650,185,230);
 glow.addColorStop(0,'#fff2c4aa');glow.addColorStop(1,'#fff2c400');
 ctx.fillStyle=glow;ctx.fillRect(400,0,500,ground);
 // Soft rounded clouds instead of block clouds.
 for(let i=0;i<6;i++){
   const x=((i*190-worldDistance*.12)%1120+1120)%1120-90,y=60+(i%3)*48;
   ctx.fillStyle='#ffe7d9';ctx.beginPath();
   ctx.ellipse(x+35,y+8,43,12,0,0,Math.PI*2);
   ctx.ellipse(x+20,y+3,20,13,0,0,Math.PI*2);
   ctx.ellipse(x+48,y-4,24,17,0,0,Math.PI*2);
   ctx.fill();
 }
 // Layered Delhi skyline.
 for(let i=0;i<16;i++){
   const x=i*68-(worldDistance*.09%68),h=30+(i*31%58);
   rect(x,ground-130-h,54,h,'#8c7a8c');
   rect(x+6,ground-135-h,42,6,'#8c7a8c');
   for(let j=0;j<3;j++)rect(x+9+j*13,ground-118-h,5,8,'#e9c4aa');
 }
 // India Gate inspired landmark with arch cutout.
 ctx.fillStyle='#c88b78';
 ctx.beginPath();ctx.moveTo(685,240);ctx.lineTo(698,157);ctx.lineTo(720,157);ctx.lineTo(728,119);ctx.lineTo(792,119);ctx.lineTo(800,157);ctx.lineTo(821,157);ctx.lineTo(835,240);ctx.closePath();ctx.fill();
 rect(680,235,160,9,'#b97b70');rect(710,160,100,5,'#f0b79a');
 ctx.fillStyle='#8a7183';ctx.beginPath();ctx.moveTo(739,240);ctx.lineTo(744,185);ctx.quadraticCurveTo(760,168,776,185);ctx.lineTo(781,240);ctx.closePath();ctx.fill();
 // Trees with rounded canopies and gentle parallax.
 for(let i=0;i<18;i++){
   const x=((i*65-worldDistance*.19)%1120+1120)%1120-60;
   rect(x,276,7,95,'#64564f');
   ctx.fillStyle=i%2?'#28684f':'#32795a';ctx.beginPath();
   ctx.arc(x+2,263,21,0,Math.PI*2);ctx.arc(x-9,274,15,0,Math.PI*2);ctx.arc(x+14,275,15,0,Math.PI*2);ctx.fill();
   ctx.fillStyle='#3e8a64';ctx.beginPath();ctx.arc(x+1,250,13,0,Math.PI*2);ctx.fill();
 }
 // Protest crowd silhouettes and flags.
 for(let i=0;i<88;i++){
   const x=((i*27-worldDistance*.42)%1050+1050)%1050-25,y=334+(i%4)*7;
   ctx.fillStyle=i%4===0?'#a94b4b':i%3===0?'#d4a07e':'#29394e';
   ctx.beginPath();ctx.arc(x+3,y-5,3.5,0,Math.PI*2);ctx.fill();
   rect(x,y,6,14,i%4===0?'#a94b4b':'#29394e');
   if(i%12===0){rect(x+7,y-31,2,30,'#59453e');ctx.fillStyle='#f02e43';ctx.beginPath();ctx.moveTo(x+9,y-30);ctx.lineTo(x+31,y-25);ctx.lineTo(x+9,y-17);ctx.closePath();ctx.fill();}
 }
 // Foreground red flags.
 for(let i=0;i<7;i++){
   const x=((i*157-worldDistance*.63)%1050+1050)%1050;
   rect(x,270,3,57,'#65473e');
   ctx.fillStyle='#f12f43';ctx.beginPath();ctx.moveTo(x+3,272);ctx.lineTo(x+35,278);ctx.lineTo(x+3,293);ctx.closePath();ctx.fill();
   line(x+5,276,x+26,279,'#ff9297',1);
 }
}
function drawGround(){
 const road=ctx.createLinearGradient(0,ground,0,540);road.addColorStop(0,'#424a55');road.addColorStop(1,'#222a34');
 ctx.fillStyle=road;ctx.fillRect(0,ground,960,115);
 rect(0,ground,960,8,'#f1d6a5');rect(0,ground+8,960,3,'#8f969e');
 for(let x=-(worldDistance%112);x<1000;x+=112){
   rect(x,ground+18,68,6,'#89919a');rect(x+14,ground+45,46,3,'#555f6b');
   rect(x+34,ground+68,54,2,'#3e4752');
 }
 rect(0,ground+92,960,8,'#161e26');
}
function drawBarricade(o){let x=o.x,y=ground-58;rect(x,y, o.w,48,'#eaa91d');rect(x+4,y+5,o.w-8,36,'#f6c44c');rect(x+8,y+10,o.w-16,6,'#b66b15');rect(x+8,y+27,o.w-16,6,'#b66b15');rect(x+6,y+43,8,12,'#c87b13');rect(x+o.w-14,y+43,8,12,'#c87b13');text(o.type==='police'?'RIVAL': 'DELHI POLICE',x+o.w/2,y+25, o.w<70?9:11,'#842a20','center');}
function drawCone(o){let x=o.x,y=ground-45;rect(x+9,y+5,16,32,'#f04a37');rect(x+5,y+16,24,8,'#f6f0dc');rect(x,y+37,34,7,'#f4e6c9')}
function drawPolice(o){
 const x=o.x,y=ground-83;
 // Shadow and boots
 ctx.fillStyle='#11192380';ctx.beginPath();ctx.ellipse(x+34,ground+1,35,5,0,0,Math.PI*2);ctx.fill();
 rect(x+13,y+64,15,13,'#182330');rect(x+36,y+64,16,13,'#182330');
 rect(x+8,y+73,23,6,'#111a24');rect(x+32,y+73,24,6,'#111a24');
 // Khaki uniform legs and torso
 rect(x+14,y+43,14,24,'#8f774b');rect(x+35,y+42,14,25,'#a18a5c');
 rect(x+13,y+25,39,27,'#b6a071');rect(x+8,y+29,13,21,'#b6a071');rect(x+47,y+29,12,17,'#b6a071');
 rect(x+17,y+30,31,4,'#776443');rect(x+29,y+30,4,21,'#786344');
 // Shoulder patches and badge
 rect(x+15,y+25,9,5,'#4c5e78');rect(x+42,y+25,8,5,'#4c5e78');rect(x+36,y+35,6,7,'#d8bd71');
 // Neck, face, moustache
 rect(x+26,y+15,13,12,'#b87553');rect(x+21,y+2,25,23,'#b87553');
 rect(x+19,y+4,29,8,'#273b54');rect(x+21,y-2,25,10,'#273b54');rect(x+17,y+4,7,11,'#273b54');
 rect(x+25,y+11,4,3,'#1b2029');rect(x+38,y+11,4,3,'#1b2029');rect(x+29,y+17,13,4,'#32252a');
 // Riot helmet visor
 rect(x+21,y+4,25,4,'#182b42');rect(x+22,y+8,24,4,'#7892a6');
 // Arm holding baton
 rect(x+50,y+28,9,14,'#b6a071');rect(x+55,y+17,5,18,'#222c3b');rect(x+56,y+12,4,9,'#3c4858');
 // Shield foreground
 rect(x+2,y+31,19,31,'#273e58');rect(x+4,y+34,15,24,'#49647d');rect(x+5,y+36,13,4,'#b8c9d7');
 text('POLICE',x+11,y+47,5,'#f8f4e9','center');
 rect(x+3,y+60,17,3,'#18283a');
}
function drawPlayerFallback(){
 let x=player.x,y=player.y,h=player.slide?48:78;
 // Small ground shadow keeps the runner visually anchored.
 ctx.fillStyle='#141c2680';ctx.beginPath();ctx.ellipse(x+27,ground+1,28,5,0,0,Math.PI*2);ctx.fill();
 // white cloth/scarf trailing behind, based on supplied photo's white shoulder cloth
 rect(x-12,y+12,25,42,'#f4eee2');rect(x-8,y+14,17,31,'#d7d9df');rect(x+2,y+18,9,7,'#d93a40');
 // legs
 if(player.slide){rect(x+5,y+37,42,10,'#202b3c');rect(x+34,y+39,23,8,'#202b3c')}
 else {rect(x+12,y+54,13,22,'#222c3d');rect(x+31,y+54,13,22,'#222c3d');rect(x+7,y+72,19,6,'#eee9df');rect(x+29,y+72,19,6,'#eee9df')}
 // navy shirt/torso and arms
 rect(x+9,y+23,36,34,'#333c65');rect(x+3,y+29,11,25,'#333c65');rect(x+40,y+29,13,9,'#d99b78');rect(x+45,y+25,8,9,'#d99b78');
 // head, hair, moustache
 rect(x+15,y+1,31,28,'#c98763');rect(x+12,y+1,34,10,'#26242a');rect(x+15,y-4,25,8,'#26242a');rect(x+11,y+5,8,12,'#26242a');rect(x+23,y+12,4,3,'#19191d');rect(x+37,y+12,4,3,'#19191d');rect(x+27,y+18,15,5,'#292026');rect(x+25,y+22,17,3,'#292026');
}

function drawPlayer(){
 const jumpOffset=Math.max(0,(ground-player.h)-player.y);
 const shadowStrength=Math.max(.12,1-jumpOffset/210);
 const shadowWidth=Math.max(12,29-jumpOffset*.085);
 ctx.save();
 ctx.globalAlpha=shadowStrength*.58;
 const groundShadow=ctx.createRadialGradient(player.x+27,ground+1,2,player.x+27,ground+1,shadowWidth);
 groundShadow.addColorStop(0,'#111923');groundShadow.addColorStop(1,'#11192300');
 ctx.fillStyle=groundShadow;ctx.beginPath();ctx.ellipse(player.x+27,ground+1,shadowWidth,Math.max(2,5-jumpOffset*.012),0,0,Math.PI*2);ctx.fill();
 ctx.restore();
 const sliding=player.slide>0;
 let pool=sliding?slideSprites:(jumpOffset>2?jumpSprites:runSprites);
 let idx;
 if(sliding) idx=Math.floor(frame/5)%pool.length;
 else if(jumpOffset>2) idx=player.vy < -180 ? 0 : player.vy < 80 ? 1 : player.vy < 420 ? 2 : Math.min(3,pool.length-1);
 else idx=Math.floor(frame/6)%pool.length;
 const sprite=pool[idx] || pool.find(im=>im.complete&&im.naturalWidth>0);
 if(!sprite || !sprite.complete || !sprite.naturalWidth){
   // Brief loading fallback; sprite images are embedded in this file and will replace this immediately.
   drawPlayerFallback();return;
 }
 const targetH=sliding?88:(jumpOffset>2?142:136);
 const ratio=sprite.naturalWidth/sprite.naturalHeight;
 const targetW=targetH*ratio;
 const x=player.x-(targetW-54)*.5-3;
 const y=ground-targetH-jumpOffset;
 ctx.save();
 ctx.imageSmoothingEnabled=true;
 ctx.shadowColor='transparent';ctx.shadowBlur=0;ctx.drawImage(sprite,x,y,targetW,targetH);
 ctx.restore();
}

function drawBanner(o) {
 const y = ground - 115;
 // Only the hanging sign is solid; thin suspension wires are decorative.
 line(o.x + 8, 0, o.x + 8, y, '#4a5155', 2);
 line(o.x + o.w - 8, 0, o.x + o.w - 8, y, '#4a5155', 2);
 rect(o.x, y, o.w, 75, '#243c49');
 rect(o.x + 4, y + 4, o.w - 8, 67, '#365667');
 rect(o.x, y + 65, o.w, 10, '#f1c75d');
 text('SLIDE', o.x + o.w / 2, y + 27, 14, '#fff0d1', 'center');
 text('↓', o.x + o.w / 2, y + 53, 27, '#fff0d1', 'center');
}
function draw(state, reducedMotion = false) {
 player = state.player; frame = state.frame; worldDistance = reducedMotion ? 0 : state.worldDistance;
 drawSky(); drawGround();
 rect(790,300,145,36,'#d8a45e');rect(796,306,133,24,'#f4cf8c');text('JANTAR MANTAR',862,322,13,'#673a2d','center');
 state.collectibles.forEach(c => {
   const bob = reducedMotion ? 0 : Math.sin((frame + c.x) * .08) * 4;
   ctx.fillStyle = '#ffedb835'; ctx.beginPath(); ctx.arc(c.x + 15, ground - 92 + bob, 25, 0, Math.PI * 2); ctx.fill();
   rect(c.x,ground-104+bob,5,29,'#e8e3d5');rect(c.x+5,ground-102+bob,26,17,'#f0263b');
   text('+10',c.x+12,ground-112+bob,10,'#fff','center');
 });
 state.obstacles.forEach(o => o.type === 'banner' ? drawBanner(o) : o.type === 'cone' ? drawCone(o) : o.type === 'police' ? drawPolice(o) : drawBarricade(o));
 if (state.mode !== 'home') drawPlayer();
 if (!reducedMotion) state.particles.forEach(p => {
   ctx.globalAlpha = Math.max(0, Math.min(1, p.life / .45)); rect(p.x,p.y,4,4,p.c);
 });
 ctx.globalAlpha = 1;
}
return { draw, resize, ready, get missingSprites() { return allSprites.filter(im => !im.naturalWidth).length; } };
}

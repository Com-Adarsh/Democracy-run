const SETTINGS_KEY = 'rjm-settings-v2';
export function readBest(storage) {
  try { const n = Number(storage?.getItem('rjm-best')); return Number.isFinite(n) && n >= 0 ? Math.floor(n) : 0; }
  catch { return 0; }
}
export function writeBest(storage, value) {
  try { storage?.setItem('rjm-best', String(Math.floor(value))); return Boolean(storage); } catch { return false; }
}
export function readSettings(storage, reducedMotion = false) {
  const defaults = { sound: false, music: false, reducedMotion };
  try {
    const saved = JSON.parse(storage?.getItem(SETTINGS_KEY) || '{}');
    for (const key of Object.keys(defaults)) if (typeof saved?.[key] === 'boolean') defaults[key] = saved[key];
  } catch { /* Storage can be disabled or contain invalid JSON. */ }
  return defaults;
}
export function writeSettings(storage, settings) {
  try { storage?.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch { /* Session-only settings still work. */ }
}

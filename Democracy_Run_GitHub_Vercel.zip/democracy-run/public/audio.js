// Original v1.3 synthesized melody; no downloaded music or audio libraries.
export function createAudio() {
  let context, timer = null, step = 0;
  const active = new Set();
  const lead = [659,0,784,988,0,784,659,523,587,0,698,880,0,698,587,494,523,0,659,784,0,659,587,440,494,0,587,740,0,587,523,392];
  const bass = [131,131,165,165,147,147,123,123];
  function unlock() {
    try {
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (!Audio) return false;
      context ||= new Audio();
      if (context.state === 'suspended') context.resume().catch(() => {});
      return true;
    } catch { return false; }
  }
  function note(frequency, duration, kind = 'square', volume = 0.018) {
    if (!context || context.state !== 'running') return;
    const oscillator = context.createOscillator(), gain = context.createGain();
    const filter = context.createBiquadFilter(), now = context.currentTime;
    oscillator.type = kind; oscillator.frequency.value = frequency;
    filter.type = 'lowpass'; filter.frequency.value = kind === 'triangle' ? 2200 : 1400;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(volume, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    oscillator.connect(filter); filter.connect(gain); gain.connect(context.destination);
    active.add(oscillator);
    oscillator.onended = () => { active.delete(oscillator); oscillator.disconnect(); gain.disconnect(); filter.disconnect(); };
    oscillator.start(now); oscillator.stop(now + duration + 0.03);
  }
  function stop() {
    if (timer !== null) { clearInterval(timer); timer = null; }
    for (const oscillator of active) { try { oscillator.stop(); } catch {} }
    active.clear();
  }
  function play() {
    if (timer !== null) return true;
    if (!unlock()) return false;
    step = 0;
    timer = setInterval(() => {
      if (lead[step % lead.length]) note(lead[step % lead.length], 0.105);
      if (step % 4 === 0) note(bass[Math.floor(step / 4) % bass.length], 0.28, 'triangle', 0.035);
      if (step % 2 === 0) note(110, 0.035, 'sawtooth', 0.006);
      step++;
    }, 145);
    return true;
  }
  return { unlock, play, stop, beep: (frequency = 500, duration = 0.07) => note(frequency, duration, 'sine', 0.04) };
}

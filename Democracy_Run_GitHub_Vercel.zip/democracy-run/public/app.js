import { createGame, createClock, formatScore } from './core.js';
import { createRenderer } from './renderer.js';
import { createAudio } from './audio.js';
import { readBest, writeBest, readSettings, writeSettings } from './storage.js';

const $ = id => document.getElementById(id);
let storage;
try { storage = window.localStorage; } catch { storage = null; }
let best = readBest(storage);
const settings = readSettings(storage, window.matchMedia('(prefers-reduced-motion: reduce)').matches);
const audio = createAudio();
let renderer, clock, raf = 0, utilityFocus = null;
const game = createGame({ onEvent });

function announce(message) { $('announcement').textContent = message; }
function closeDialogs() { document.querySelectorAll('dialog[open]').forEach(dialog => dialog.close()); }
function showDialog(id) {
  closeDialogs();
  const dialog = $(id);
  if (typeof dialog.showModal === 'function') dialog.showModal();
  else { dialog.setAttribute('open', ''); $('load-error').hidden = false; $('load-error').textContent = 'For the best experience, use a current browser with dialog support.'; }
}
function requestRender() { if (!raf && renderer) raf = requestAnimationFrame(renderFrame); }
function renderFrame(timestamp) {
  raf = 0; clock.tick(timestamp);
  renderer.draw(game.state, settings.reducedMotion);
  updateStats();
  if (game.state.mode === 'running') requestRender();
}
function updateStats() {
  const s = game.state;
  $('score').textContent = formatScore(s.score); $('best').textContent = formatScore(best); $('flags').textContent = s.flags;
  $('pace').textContent = s.mode === 'running' ? `${(s.speed / 330).toFixed(2)}× PACE` : s.mode === 'paused' ? 'PAUSED' : s.mode === 'over' ? 'RUN COMPLETE' : 'READY TO RUN';
  $('pause').disabled = s.mode !== 'running';
  $('jump').disabled = $('slide').disabled = s.mode !== 'running';
}
function syncSettings() {
  $('sound').setAttribute('aria-pressed', String(settings.sound));
  $('sound').querySelector('span').textContent = settings.sound ? 'ON' : 'OFF';
  $('music').setAttribute('aria-pressed', String(settings.music));
  $('music').querySelector('span').textContent = settings.music ? 'ON' : 'OFF';
  $('setting-sound').checked = settings.sound; $('setting-music').checked = settings.music;
  $('setting-motion').checked = settings.reducedMotion;
  document.documentElement.classList.toggle('reduced-motion', settings.reducedMotion);
  writeSettings(storage, settings);
  if (settings.music && game.state.mode === 'running') {
    if (!audio.play()) announce('Audio is unavailable in this browser. You can still play.');
  } else audio.stop();
  requestRender();
}
function setSetting(key, value) {
  settings[key] = value;
  if ((key === 'sound' || key === 'music') && value && !audio.unlock()) {
    settings[key] = false; announce('Audio is unavailable in this browser.');
  }
  syncSettings();
  if (key === 'sound' && settings.sound) audio.beep(500);
}
function onEvent(event, state) {
  if (event === 'start' || event === 'resume') {
    closeDialogs(); clock?.reset();
    $('home-screen').hidden = true; $('stage').classList.remove('is-home'); $('scene-label').hidden = false;
    $('run-status').textContent = '↑ Jump obstacles · ↓ Slide under banners';
    if (settings.sound || settings.music) audio.unlock();
    if (settings.music) audio.play();
    if (event === 'start' && settings.sound) audio.beep(500);
    $('game').focus({ preventScroll: true });
    announce(event === 'start' ? 'Run started.' : 'Run resumed.');
  } else if (event === 'pause') {
    audio.stop(); clock?.reset(); showDialog('pause-dialog');
    $('run-status').textContent = 'Your run is paused.'; announce('Run paused.');
  } else if (event === 'over') {
    audio.stop();
    if (settings.sound) audio.beep(120, 0.2);
    const finalScore = Math.floor(state.score), record = finalScore > best;
    best = Math.max(best, finalScore);
    if (!writeBest(storage, best)) $('storage-note').textContent = 'Browser storage is unavailable. Your best score is kept for this session.';
    $('result-score').textContent = formatScore(finalScore); $('result-flags').textContent = state.flags;
    $('result-best').textContent = formatScore(best);
    $('result-eyebrow').textContent = record ? '★ A NEW PERSONAL BEST' : 'THE MOVEMENT CONTINUES';
    $('result-reason').textContent = `${Math.floor(state.elapsed)} seconds on the street. Time for another run?`;
    $('share-status').textContent = 'Press R for another run.'; $('share-fallback').hidden = true;
    $('run-status').textContent = record ? '★ New personal best. Nicely done.' : 'Every run is a fresh start.';
    showDialog('over-dialog');
    announce(`Run complete. Score ${finalScore}. ${state.flags} flags collected.${record ? ' New personal best.' : ''}`);
  } else if (event === 'home') {
    audio.stop(); clock?.reset(); closeDialogs();
    $('home-screen').hidden = false; $('stage').classList.add('is-home'); $('scene-label').hidden = true;
    $('run-status').innerHTML = '<span class="tiny-star">★</span> Ready when you are.';
    $('start').focus({ preventScroll: true });
  } else if (event === 'jump' && settings.sound) audio.beep(360);
  else if (event === 'flag') {
    if (settings.sound) audio.beep(760);
    const feedback = $('feedback'); feedback.textContent = '+10 ⚑';
    if (!settings.reducedMotion) {
      feedback.classList.remove('pop'); void feedback.offsetWidth; feedback.classList.add('pop');
    }
  }
  updateStats(); requestRender();
}
function openUtility(id) {
  utilityFocus = document.activeElement;
  if (game.state.mode === 'running') game.pause();
  showDialog(id);
}
function closeUtility(id) {
  $(id).close();
  if (game.state.mode === 'paused') showDialog('pause-dialog');
  else utilityFocus?.focus({ preventScroll: true });
}
async function shareScore() {
  // Strip tracking queries, fragments, and any local file path from shared text.
  const message = `I scored ${Math.floor(game.state.score)} and collected ${game.state.flags} flags in The Democracy Run!`;
  const url = location.protocol.startsWith('http') ? location.origin + location.pathname : '';
  const payload = { title: 'The Democracy Run', text: message, ...(url ? { url } : {}) };
  const text = message + (url ? '\n' + url : '');
  try {
    if (navigator.share) { await navigator.share(payload); $('share-status').textContent = 'Score shared.'; return; }
  } catch (error) { if (error.name === 'AbortError') return; }
  try {
    await navigator.clipboard.writeText(text); $('share-status').textContent = 'Score copied. Paste it wherever you like.';
  } catch {
    $('share-fallback').hidden = false; $('share-fallback').value = text; $('share-fallback').focus(); $('share-fallback').select();
    $('share-status').textContent = 'Select and copy your score below.';
  }
}

try {
  renderer = createRenderer($('game')); clock = createClock(game);
  renderer.ready.then(() => {
    if (renderer.missingSprites) announce('Some artwork could not load. A fallback character is available.');
    requestRender();
  });
  $('start').addEventListener('click', game.start);
  $('retry').addEventListener('click', game.start);
  $('restart-paused').addEventListener('click', game.start);
  $('pause').addEventListener('click', game.pause);
  $('resume').addEventListener('click', game.resume);
  $('home-over').addEventListener('click', game.home);
  $('home-paused').addEventListener('click', game.home);
  $('share').addEventListener('click', shareScore);
  $('instructions').addEventListener('click', () => openUtility('help-dialog'));
  $('settings').addEventListener('click', () => openUtility('settings-dialog'));
  document.querySelectorAll('[data-close]').forEach(button => button.addEventListener('click', () => closeUtility(button.dataset.close)));
  ['help-dialog', 'settings-dialog'].forEach(id => $(id).addEventListener('cancel', event => { event.preventDefault(); closeUtility(id); }));
  $('pause-dialog').addEventListener('cancel', event => { event.preventDefault(); game.resume(); });
  $('over-dialog').addEventListener('cancel', event => { event.preventDefault(); game.home(); });
  $('sound').addEventListener('click', () => setSetting('sound', !settings.sound));
  $('music').addEventListener('click', () => setSetting('music', !settings.music));
  $('setting-sound').addEventListener('change', event => setSetting('sound', event.target.checked));
  $('setting-music').addEventListener('change', event => setSetting('music', event.target.checked));
  $('setting-motion').addEventListener('change', event => setSetting('reducedMotion', event.target.checked));
  for (const [id, action] of [['jump', game.jump], ['slide', game.slide]]) {
    $(id).addEventListener('pointerdown', event => { event.preventDefault(); action(); });
    // Keyboard and assistive-technology activation do not emit pointerdown.
    $(id).addEventListener('click', event => { if (event.detail === 0) action(); });
  }
  $('game').addEventListener('pointerdown', event => { event.preventDefault(); game.jump(); });
  window.addEventListener('keydown', event => {
    if (event.repeat) return;
    const openDialog = document.querySelector('dialog[open]');
    if (openDialog) {
      if (openDialog.id === 'pause-dialog' && event.code === 'KeyP') { event.preventDefault(); game.resume(); }
      else if (openDialog.id === 'over-dialog' && event.code === 'KeyR') { event.preventDefault(); game.start(); }
      return;
    }
    if (event.target.closest?.('button, input, textarea, a, select')) return;
    if (game.state.mode === 'home' && ['Enter', 'Space'].includes(event.code)) { event.preventDefault(); game.start(); return; }
    if (game.state.mode !== 'running') return;
    if (['Space', 'ArrowUp', 'ArrowDown', 'KeyW', 'KeyS', 'KeyP', 'Escape'].includes(event.code)) event.preventDefault();
    if (['Space', 'ArrowUp', 'KeyW'].includes(event.code)) game.jump();
    if (['ArrowDown', 'KeyS'].includes(event.code)) game.slide();
    if (['KeyP', 'Escape'].includes(event.code)) game.pause();
  });
  document.addEventListener('visibilitychange', () => { if (document.hidden) game.pause(); });
  window.addEventListener('blur', game.pause);
  window.addEventListener('resize', () => { renderer.resize(); requestRender(); });
  window.addEventListener('pagehide', () => { game.pause(); audio.stop(); });
  syncSettings(); updateStats(); requestRender();
} catch (error) {
  $('load-error').hidden = false; $('load-error').textContent = 'The game could not start. Refresh this page or try a current version of Chrome, Firefox, Safari, or Edge.';
  $('start').disabled = true;
  console.error(error);
}

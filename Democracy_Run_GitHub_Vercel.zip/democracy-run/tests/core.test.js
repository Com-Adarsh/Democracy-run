import test from 'node:test';
import assert from 'node:assert/strict';
import { createGame, createClock, RULES, playerBounds, obstacleBounds, intersects } from '../public/core.js';
import { readBest, writeBest, readSettings } from '../public/storage.js';

const advance = (game, seconds) => { for (let i = 0; i < Math.round(seconds / RULES.fixedStep); i++) game.step(RULES.fixedStep); };
function quietGame(random = () => 0.5) {
  const game = createGame({ random }); game.start(); game.state.spawn = game.state.flagSpawn = 10000; return game;
}
test('score and speed retain the original rates', () => {
  const game = quietGame(); advance(game, 10);
  assert.ok(Math.abs(game.state.score - 240) < 1e-8);
  assert.ok(Math.abs(game.state.speed - 338.4) < 1e-8);
});
test('jump has one ascent, cannot double-jump, and lands on the ground', () => {
  const game = quietGame(); game.jump(); advance(game, 0.2);
  const velocity = game.state.player.vy; game.jump(); assert.equal(game.state.player.vy, velocity);
  advance(game, 0.8);
  assert.equal(game.state.player.onGround, true); assert.equal(game.state.player.y, RULES.ground - 78);
});
test('a near-landing buffered jump is honoured', () => {
  const game = quietGame(); game.jump(); advance(game, 0.75); game.jump(); advance(game, 0.12);
  assert.equal(game.state.player.onGround, false); assert.ok(game.state.player.vy < -600);
});
test('restarting clears a pending jump and slide', () => {
  const game = quietGame(); game.jump(); game.jump(); game.start();
  assert.equal(game.state.player.onGround, true); assert.equal(game.state.player.jumpBuffer, 0);
  game.slide(); game.start(); assert.equal(game.state.player.slide, 0); assert.equal(game.state.score, 0);
});
test('pause freezes the whole simulation and resume continues it', () => {
  const game = quietGame(); advance(game, 1); game.pause();
  const snapshot = JSON.stringify(game.state); advance(game, 10); game.jump(); game.slide();
  assert.equal(JSON.stringify(game.state), snapshot); game.resume(); advance(game, 1); assert.ok(game.state.score > 47.9);
});
test('collecting a flag gives exactly 10 bonus points and removes it once', () => {
  const game = quietGame(); game.state.collectibles.push({ x: 220 }); game.step(RULES.fixedStep);
  assert.equal(game.state.flags, 1); assert.equal(game.state.collectibles.length, 0);
  assert.ok(Math.abs(game.state.score - (10 + 24 * RULES.fixedStep)) < 1e-10);
  advance(game, 0.1); assert.equal(game.state.flags, 1);
});
for (const type of ['cone', 'barrier', 'police']) {
  test(`standing collides with a ${type}, while a timed jump clears it`, () => {
    const game = quietGame(); game.state.obstacles.push({ x: 230, w: type === 'cone' ? 34 : 76, type });
    game.step(RULES.fixedStep); assert.equal(game.state.mode, 'over');
    const jumping = quietGame(); jumping.jump(); advance(jumping, 0.25);
    jumping.state.obstacles.push({ x: 245, w: type === 'cone' ? 34 : 76, type });
    advance(jumping, 0.4); assert.equal(jumping.state.mode, 'running');
  });
}
test('slide stays on the road and clears a hanging banner', () => {
  const game = quietGame(); const banner = { x: 230, w: 100, type: 'banner' };
  assert.ok(intersects(playerBounds(game.state.player), obstacleBounds(banner)));
  game.slide(); const box = playerBounds(game.state.player); assert.equal(box.y + box.h, RULES.ground);
  game.state.obstacles.push(banner); advance(game, 0.45); assert.equal(game.state.mode, 'running');
  advance(game, 0.2); assert.equal(game.state.player.slide, 0);
});
test('sliding does not grant immunity from ground obstacles', () => {
  const game = quietGame(); game.slide(); game.state.obstacles.push({ x: 230, w: 76, type: 'barrier' });
  game.step(RULES.fixedStep); assert.equal(game.state.mode, 'over');
});
test('the old narrow-barricade branch is repaired', () => {
  const game = createGame({ random: () => 0.27 }); game.start(); advance(game, 0.75);
  assert.equal(game.state.obstacles[0].type, 'barrier'); assert.equal(game.state.obstacles[0].w, 76);
});
test('overhead banners are introduced only after 240 points', () => {
  const game = createGame({ random: () => 0.97 }); game.start(); advance(game, 0.75);
  assert.equal(game.state.obstacles[0].type, 'police');
  game.state.score = 250; game.state.spawn = 0; game.step(RULES.fixedStep);
  assert.equal(game.state.obstacles.at(-1).type, 'banner');
});
test('fixed-step gameplay matches at 30, 60, and 144 Hz', () => {
  const outcomes = [30, 60, 144].map(hz => {
    const game = quietGame(); game.jump(); const clock = createClock(game); clock.tick(0);
    for (let i = 1; i <= hz * 2; i++) clock.tick(i * 1000 / hz);
    return [game.state.score, game.state.worldDistance, game.state.player.y, game.state.player.vy];
  });
  assert.deepEqual(outcomes[0], outcomes[1]); assert.deepEqual(outcomes[1], outcomes[2]);
});
test('long frame gaps are capped rather than fast-forwarding the game', () => {
  const game = quietGame(), clock = createClock(game); clock.tick(0); clock.tick(100000);
  assert.ok(game.state.score < 2.5);
});
test('high speed is capped and scene objects are removed offscreen', () => {
  const game = quietGame(); game.state.score = 1e6;
  game.state.obstacles.push({ x: -150, w: 76, type: 'barrier' });
  game.state.collectibles.push({ x: -100 }); advance(game, 1);
  assert.equal(game.state.speed, 650); assert.equal(game.state.obstacles.length, 0); assert.equal(game.state.collectibles.length, 0);
});
test('invalid and unavailable storage never breaks play', () => {
  for (const value of ['NaN', 'Infinity', '-3', '{bad}']) assert.equal(readBest({ getItem: () => value }), 0);
  const blocked = { getItem() { throw Error('denied'); }, setItem() { throw Error('denied'); } };
  assert.equal(readBest(blocked), 0); assert.equal(writeBest(blocked, 100), false);
  assert.deepEqual(readSettings(blocked, true), { sound: false, music: false, reducedMotion: true });
  assert.deepEqual(readSettings({ getItem: () => '{"sound":"yes","music":true}' }), { sound: false, music: true, reducedMotion: false });
});
